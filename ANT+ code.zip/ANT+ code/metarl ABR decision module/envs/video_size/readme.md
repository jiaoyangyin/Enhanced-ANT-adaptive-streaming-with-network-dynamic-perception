## Video size

The files of streaming video sizes are obtained following the DASH proposal, using ffmpeg and MP4Box open source software

The source video in ```./Mao/``` is unknown, we copy them from the [repository](https://github.com/hongzimao/pensieve), with a length of ```48*4s```.

The source video of ```SSB``` is download from [sita_sings_the_blues](https://media.xiph.org/video/derf/), with a length of ```200*4s```.